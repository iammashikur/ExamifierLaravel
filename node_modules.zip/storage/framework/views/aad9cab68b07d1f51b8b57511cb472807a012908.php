<?php $__env->startSection('content'); ?>



<div class="container exam-conatiner">


    <div class="row">
        <div class="col-12 mb-4">
            <?php $__currentLoopData = $data->Exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <h2 class="text-center mt-4"><?php echo e($xm->name); ?></h2>
                <p class="text-center mt-2">Subject : <?php echo e($xm->subject); ?></p>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



    <div class="row">
        <div class="col-md-12">

            <div class="exam-form mb-4">



            <input type="hidden" value="<?php echo e(Request::segment(3)); ?>" name="exam_id">

                    <div class="row">

                        <div class="col-12">

                            <button type="button" class="btn btn-secondary mb-4">MCQ Question</button>

                        </div>

                        <?php
                            $index =1;
                            $marks =0;
                        ?>

                        <?php $__currentLoopData = $data->McQs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php




                            if (isset($my_data->{'mcq_'.$index})) {

                                $my_answer = $my_data->{'mcq_'.$index};

                                if ($mc->answer == $my_answer)
                                {
                                    $status = "correct";
                                    $marks =$marks+1;
                                }

                                else

                                {
                                    $status = "incorrect";
                                    $marks =$marks-0.5;
                                }

                            }
                            else {
                                $my_answer = "0";
                                $status = "incorrect";
                            }

                            ?>

                        <div class="col-md-6 col-12 mb-4">

                            <div class="mcq-box border p-4" <?php if($status == "correct"): ?> style="background: rgb(203, 204, 247)" <?php else: ?> style="background: rgb(247, 200, 200)"  <?php endif; ?>>

                                <div class="row">

                                    <div class="col-12 mb-2">

                                        <p class="btn btn-success btn-sm mb-4">
                                            (<?php echo e($index); ?>)
                                        </p>


                                        <?php if($status == "correct"): ?>
                                        <p class="btn btn-success btn-sm mb-4">
                                            Correct Answer
                                        </p>
                                        <?php else: ?>
                                        <p class="btn btn-danger btn-sm mb-4">
                                            Incorrect Answer
                                        </p>

                                        <p class="btn btn-success btn-sm mb-4">
                                            Correct : <?php echo e($mc->answer); ?>

                                        </p>
                                        <?php endif; ?>



                                        <p><?php echo e($mc->question); ?></p>

                                    </div>



                                    <div class="col-12">
                                        <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_1" value="A" <?php if($my_answer == "A"): ?> checked <?php endif; ?>>
                                              <?php echo e($mc->mcq_1); ?>

                                            </label>
                                          </div>
                                          <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_2" value="B" <?php if($my_answer == "B"): ?> checked <?php endif; ?>>
                                              <?php echo e($mc->mcq_2); ?>

                                            </label>
                                          </div>

                                          <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_3" value="C" <?php if($my_answer == "C"): ?> checked <?php endif; ?>>
                                              <?php echo e($mc->mcq_3); ?>

                                            </label>
                                          </div>

                                          <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_4" value="D" <?php if($my_answer == "D"): ?> checked <?php endif; ?>>
                                              <?php echo e($mc->mcq_4); ?>

                                            </label>
                                          </div>

                                    </div>








                                </div>

                            </div>



                        </div>


                    <?php
                        $index++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>


                    <button type="button" class="btn btn-dark mb-4">Total Marks :  <?php echo e($marks); ?></button>


            </div>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Examifier\resources\views/student_result.blade.php ENDPATH**/ ?>