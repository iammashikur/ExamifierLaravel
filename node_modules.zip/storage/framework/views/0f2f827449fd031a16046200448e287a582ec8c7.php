<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-md-3 mt-4">

            <div class="list-group">

                <a href="<?php echo e(url('student/dashboard')); ?>" class="list-group-item list-group-item-action active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a href="<?php echo e(url('student/exams')); ?>" class="list-group-item list-group-item-action"><i class="fas fa-pencil-ruler"></i> Exams</a>
                <a href="<?php echo e(url('student/results')); ?>" class="list-group-item list-group-item-action"><i class="fas fa-clock"></i> Results</a>
                <a href="<?php echo e(url('student/notice')); ?>" class="list-group-item list-group-item-action"><i class="fas fa-exclamation-triangle"></i> Notice</a>

            </div>

        </div>


        <div class="col-md-9 mt-4">

            <div class="row">

                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $check = App\StudentData::where('student_id', Auth::user()->id)->where('exam_id', $item->id)->count();
                ?>

                <?php if($check == 0): ?>

                <div class="col-md-4">
                    <a href="<?php echo e(url('/student/exam/')); ?>/<?php echo e($item->id); ?>">
                    <div class="card text-white bg-primary mb-4" style="max-width: 20rem;">
                        <div class="card-header"><?php echo e($item->name); ?></div>
                        <div class="card-body">

                            <center>
                                <div class="mb-4" style="background:rgb(248, 79, 0); width: 60px;
                                height: 60px; border-radius:50px;">
                                    <i style="font-size: 20px; margin-top:1.2rem" class="fas fa-drafting-compass "></i>

                                </div>
                            </center>

                          
                        </div>
                      </div>
                    </a>
               </div>


                <?php endif; ?>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





            </div>


        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Examifier\resources\views/student_exams.blade.php ENDPATH**/ ?>