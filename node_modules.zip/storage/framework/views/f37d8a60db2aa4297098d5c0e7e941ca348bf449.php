<?php $__env->startSection('content'); ?>




<div class="container exam-conatiner">


    <div class="row">
        <div class="col-12 mb-4">

            <?php $__currentLoopData = $data->Exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class="text-center mt-4"><?php echo e($xm->name); ?></h2>
                <p class="text-center mt-4">Subject : <?php echo e($xm->subject); ?></p>
                <?php
                    $xm_time = $xm->time;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



    <div class="row">
        <div class="col-md-12">

            <div class="exam-form mb-4">
            <form id="examForm" class="mt-4" action="<?php echo e(route('student.exam_complete')); ?>" method="POST">
                <?php echo csrf_field(); ?>

            <input type="hidden" value="<?php echo e(Request::segment(3)); ?>" name="exam_id">

                    <div class="row">

                        <div class="col-12">

                            <button type="button" class="btn btn-secondary mb-4">MCQ Question</button> <p class="btn btn-primary mb-4" id="counter"></p>

                        </div>

                        <?php $__currentLoopData = $data->McQs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-6 col-12 mb-4">

                            <div class="mcq-box border p-4">

                                <div class="row">

                                    <div class="col-12 mb-2">

                                        <p class="btn btn-defaullt btn-sm mb-4">
                                            MCQ (1)
                                        </p>

                                        <p class="btn btn-default btn-sm mb-4">
                                            +1 / -0.5 (For Wrong Answer)
                                        </p>

                                        <p><?php echo e($mc->question); ?></p>

                                    </div>

                                    <div class="col-12">
                                        <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_1" value="A">
                                              <?php echo e($mc->mcq_1); ?>

                                            </label>
                                          </div>
                                          <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_2" value="B">
                                              <?php echo e($mc->mcq_2); ?>

                                            </label>
                                          </div>

                                          <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_3" value="C">
                                              <?php echo e($mc->mcq_3); ?>

                                            </label>
                                          </div>

                                          <div class="form-check mb-2">
                                            <label class="form-check-label">
                                              <input class="form-check-input" type="radio" name="mcq_<?php echo e($mc->id); ?>" id="mcq_<?php echo e($mc->id); ?>_4" value="D">
                                              <?php echo e($mc->mcq_4); ?>

                                            </label>
                                          </div>

                                    </div>








                                </div>

                            </div>



                        </div>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>











                    </div>


                    <button type="submit" class="btn btn-success">Submit</button>




                </form>
            </div>

        </div>
    </div>
</div>


<script>
    var varTimerInMiliseconds = 3600000*<?= $xm_time ?>;
    setTimeout(function(){
        document.getElementById("examForm").submit();
    }, varTimerInMiliseconds);
</script>

<script>

    function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds;

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

window.onload = function () {
    var fiveMinutes = 60 *<?= $xm_time ?>,
        display = document.querySelector('#counter');
    startTimer(fiveMinutes, display);
};

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Examifier\resources\views/student_exam.blade.php ENDPATH**/ ?>