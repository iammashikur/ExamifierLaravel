<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{

    public function login()
    {
        return view('auth.backend_login');
    }

    public function index()
    {
        return view('student_dashboard');
    }
}
